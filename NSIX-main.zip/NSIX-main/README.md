# NSIX
# AUTOMATIC SIX DIGIT FACEBOOK ACCOUNT CRACKER
Termux Commands

apt update 

apt install python2

apt install git

$HOME

git clone https://github.com/nfs-tech-bd/NSIX

cd NSIX

python2 NSIX.py

INBOX ME FOR TOOLS PASSWORD 🐸
# ENJOY
